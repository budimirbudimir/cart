declare module "react-nouislider";

declare type document = any // ugly fix, little time left ¯\_(ツ)_/¯
